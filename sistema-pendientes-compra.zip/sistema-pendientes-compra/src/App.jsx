import React, { useState, useEffect } from 'react';
import { Download, Plus, LogOut, User, Clock, Calendar, Package, Building2, Users, Search, Trash2, UserPlus } from 'lucide-react';

const PendientesCompraSystem = () => {
  // Usuarios del sistema con roles y contraseñas
  const [usuarios, setUsuarios] = useState({
    'CCOMETA': { nombre: 'CARLOS HERNAN COMETA OSSO', rol: 'compras', password: 'CC123' },
    'JKTRUJILLO': { nombre: 'JEAN KARLO TRUJILLO', rol: 'compras', password: 'JK.2026' },
    'JSTERLING': { nombre: 'JAVIER STERLING BERMUDEZ', rol: 'compras', password: 'JS.2026' },
    'AMSANCHEZ': { nombre: 'ANA MARIA SANCHEZ', rol: 'compras', password: 'AN.2026' },
    'DAYANNA.V1': { nombre: 'DAYANNA - VENTAS 1', rol: 'facturacion', password: 'DV1.123' },
    'KATALINA.V2': { nombre: 'KATALINA - VENTAS 2', rol: 'facturacion', password: 'KV2.123' },
    'JULIETH.V3': { nombre: 'JULIETH - VENTAS 3', rol: 'facturacion', password: 'JV3.123' },
    'MARICELA.V4': { nombre: 'MARICELA - VENTAS 4', rol: 'facturacion', password: 'MV4.123' }
  });

  const [usuarioActual, setUsuarioActual] = useState(null);
  const [loginData, setLoginData] = useState({ usuario: '', password: '' });
  const [loginError, setLoginError] = useState('');
  const [cargando, setCargando] = useState(true);
  
  const [pendientes, setPendientes] = useState([]);
  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [mostrarAgregarUsuario, setMostrarAgregarUsuario] = useState(false);
  
  // Filtros
  const [filtros, setFiltros] = useState({
    cliente: '',
    empresa: 'TODAS',
    fechaInicio: '',
    fechaFin: ''
  });

  const [nuevoPendiente, setNuevoPendiente] = useState({
    fecha: new Date().toISOString().split('T')[0],
    producto: '',
    marca: '',
    cantidad: '',
    cliente: '',
    empresa: 'IMPSURMEDICALS'
  });

  const [nuevoUsuario, setNuevoUsuario] = useState({
    usuario: '',
    nombre: '',
    rol: 'facturacion',
    password: ''
  });

  // Cargar usuarios y pendientes al iniciar
  useEffect(() => {
    cargarDatos();
  }, []);

  // Cargar datos del almacenamiento
  const cargarDatos = async () => {
    try {
      // Cargar usuarios
      const resultadoUsuarios = await window.storage.get('usuarios-sistema', true);
      if (resultadoUsuarios && resultadoUsuarios.value) {
        setUsuarios(JSON.parse(resultadoUsuarios.value));
      }

      // Cargar pendientes
      const resultadoPendientes = await window.storage.get('pendientes-compra', true);
      if (resultadoPendientes && resultadoPendientes.value) {
        setPendientes(JSON.parse(resultadoPendientes.value));
      }
    } catch (error) {
      console.log('Iniciando con datos por defecto');
    } finally {
      setCargando(false);
    }
  };

  // Guardar usuarios
  const guardarUsuarios = async (nuevosUsuarios) => {
    try {
      await window.storage.set('usuarios-sistema', JSON.stringify(nuevosUsuarios), true);
      setUsuarios(nuevosUsuarios);
    } catch (error) {
      console.error('Error al guardar usuarios:', error);
      alert('Error al guardar usuarios');
    }
  };

  // Guardar pendientes
  const guardarPendientes = async (nuevosPendientes) => {
    try {
      await window.storage.set('pendientes-compra', JSON.stringify(nuevosPendientes), true);
      setPendientes(nuevosPendientes);
    } catch (error) {
      console.error('Error al guardar:', error);
      alert('Hubo un error al guardar los datos. Por favor intenta de nuevo.');
    }
  };

  // Calcular días pendientes
  const calcularDiasPendientes = (fecha) => {
    const hoy = new Date();
    const fechaPendiente = new Date(fecha);
    const diferencia = Math.floor((hoy - fechaPendiente) / (1000 * 60 * 60 * 24));
    return diferencia;
  };

  // Obtener color según días pendientes
  const obtenerColor = (pendiente) => {
    if (pendiente.estado === 'ok') return 'bg-green-50 border-green-300';
    const dias = calcularDiasPendientes(pendiente.fecha);
    if (dias > 1) return 'bg-red-50 border-red-300';
    return 'bg-yellow-50 border-yellow-300';
  };

  // Login
  const handleLogin = (e) => {
    if (e) e.preventDefault();
    const usuario = usuarios[loginData.usuario.toUpperCase()];
    
    if (usuario && usuario.password === loginData.password) {
      setUsuarioActual({
        usuario: loginData.usuario.toUpperCase(),
        ...usuario
      });
      setLoginError('');
    } else {
      setLoginError('Usuario o contraseña incorrectos');
    }
  };

  // Logout
  const handleLogout = () => {
    setUsuarioActual(null);
    setLoginData({ usuario: '', password: '' });
  };

  // Crear pendiente
  const handleCrearPendiente = async (e) => {
    if (e) e.preventDefault();
    
    if (!nuevoPendiente.producto || !nuevoPendiente.marca || !nuevoPendiente.cantidad || !nuevoPendiente.cliente) {
      alert('Por favor completa todos los campos');
      return;
    }

    const pendiente = {
      id: Date.now(),
      ...nuevoPendiente,
      solicitadoPor: usuarioActual.nombre,
      usuarioId: usuarioActual.usuario,
      rol: usuarioActual.rol,
      estado: 'pendiente',
      observaciones: '',
      fechaCreacion: new Date().toISOString(),
      gestionadoPor: null,
      fechaGestion: null
    };

    const nuevosPendientes = [...pendientes, pendiente];
    await guardarPendientes(nuevosPendientes);
    
    setNuevoPendiente({
      fecha: new Date().toISOString().split('T')[0],
      producto: '',
      marca: '',
      cantidad: '',
      cliente: '',
      empresa: 'IMPSURMEDICALS'
    });
    setMostrarFormulario(false);
  };

  // Marcar como OK
  const marcarComoOK = async (id) => {
    const nuevosPendientes = pendientes.map(p => {
      if (p.id === id) {
        return {
          ...p,
          estado: 'ok',
          gestionadoPor: usuarioActual.nombre,
          fechaGestion: new Date().toISOString()
        };
      }
      return p;
    });
    await guardarPendientes(nuevosPendientes);
  };

  // Actualizar observaciones
  const actualizarObservaciones = async (id, observaciones) => {
    const nuevosPendientes = pendientes.map(p => {
      if (p.id === id) {
        return { ...p, observaciones };
      }
      return p;
    });
    await guardarPendientes(nuevosPendientes);
  };

  // Eliminar pendiente (solo compras)
  const eliminarPendiente = async (id) => {
    if (!window.confirm('¿Estás seguro de eliminar este pendiente?')) return;
    
    const nuevosPendientes = pendientes.filter(p => p.id !== id);
    await guardarPendientes(nuevosPendientes);
  };

  // Agregar nuevo usuario (solo compras)
  const agregarUsuario = async (e) => {
    if (e) e.preventDefault();
    
    if (!nuevoUsuario.usuario || !nuevoUsuario.nombre || !nuevoUsuario.password) {
      alert('Por favor completa todos los campos');
      return;
    }

    if (usuarios[nuevoUsuario.usuario.toUpperCase()]) {
      alert('Este usuario ya existe');
      return;
    }

    const nuevosUsuarios = {
      ...usuarios,
      [nuevoUsuario.usuario.toUpperCase()]: {
        nombre: nuevoUsuario.nombre,
        rol: nuevoUsuario.rol,
        password: nuevoUsuario.password
      }
    };

    await guardarUsuarios(nuevosUsuarios);
    
    setNuevoUsuario({
      usuario: '',
      nombre: '',
      rol: 'facturacion',
      password: ''
    });
    setMostrarAgregarUsuario(false);
    alert('Usuario agregado exitosamente');
  };

  // Filtrar pendientes
  const pendientesFiltrados = pendientes.filter(p => {
    // Filtro por cliente
    if (filtros.cliente && !p.cliente.toLowerCase().includes(filtros.cliente.toLowerCase())) {
      return false;
    }
    
    // Filtro por empresa
    if (filtros.empresa !== 'TODAS' && p.empresa !== filtros.empresa) {
      return false;
    }
    
    // Filtro por fecha inicio
    if (filtros.fechaInicio && p.fecha < filtros.fechaInicio) {
      return false;
    }
    
    // Filtro por fecha fin
    if (filtros.fechaFin && p.fecha > filtros.fechaFin) {
      return false;
    }
    
    return true;
  });

  // Exportar a Excel
  const exportarExcel = () => {
    const headers = ['Fecha', 'Producto', 'Marca', 'Cantidad', 'Cliente', 'Empresa', 'Solicitado Por', 'Días Pendiente', 'Estado', 'Observaciones', 'Gestionado Por', 'Fecha Gestión'];
    
    const rows = pendientesFiltrados.map(p => [
      p.fecha,
      p.producto,
      p.marca,
      p.cantidad,
      p.cliente,
      p.empresa,
      p.solicitadoPor,
      calcularDiasPendientes(p.fecha),
      p.estado === 'ok' ? 'OK' : 'PENDIENTE',
      p.observaciones || '',
      p.gestionadoPor || '',
      p.fechaGestion ? new Date(p.fechaGestion).toLocaleDateString() : ''
    ]);

    let csvContent = headers.join(',') + '\n';
    rows.forEach(row => {
      csvContent += row.map(cell => `"${cell}"`).join(',') + '\n';
    });

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `pendientes_compra_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  // Limpiar filtros
  const limpiarFiltros = () => {
    setFiltros({
      cliente: '',
      empresa: 'TODAS',
      fechaInicio: '',
      fechaFin: ''
    });
  };

  // Pantalla de carga
  if (cargando) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <Package className="w-16 h-16 text-indigo-600 mx-auto mb-4 animate-pulse" />
          <p className="text-gray-600 text-lg">Cargando sistema...</p>
        </div>
      </div>
    );
  }

  // Pantalla de Login
  if (!usuarioActual) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-xl p-8 w-full max-w-md">
          <div className="text-center mb-8">
            <Package className="w-16 h-16 text-indigo-600 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-800">Sistema de Pendientes</h1>
            <p className="text-gray-600 mt-2">Gestión de Compras</p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Usuario
              </label>
              <input
                type="text"
                value={loginData.usuario}
                onChange={(e) => setLoginData({ ...loginData, usuario: e.target.value })}
                onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                placeholder="Ingrese su usuario"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Contraseña
              </label>
              <input
                type="password"
                value={loginData.password}
                onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                placeholder="Ingrese su contraseña"
              />
            </div>

            {loginError && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                {loginError}
              </div>
            )}

            <button
              onClick={handleLogin}
              className="w-full bg-indigo-600 text-white py-3 rounded-lg font-medium hover:bg-indigo-700 transition-colors"
            >
              Ingresar al Sistema
            </button>
          </div>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-sm text-blue-800 font-medium mb-2">ℹ️ Información Importante:</p>
            <p className="text-xs text-blue-700">
              Toda la información se guarda automáticamente y está disponible para todos los usuarios desde cualquier computador.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Sistema principal
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-indigo-600 text-white shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              <Package className="w-8 h-8" />
              <div>
                <h1 className="text-xl font-bold">Sistema de Pendientes de Compra</h1>
                <p className="text-indigo-200 text-sm">Gestión y Control - Datos Compartidos en Tiempo Real</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="font-medium">{usuarioActual.nombre}</p>
                <p className="text-indigo-200 text-sm capitalize">
                  {usuarioActual.rol === 'compras' ? 'Equipo de Compras' : 'Auxiliar de Facturación'}
                </p>
              </div>
              <button
                onClick={handleLogout}
                className="bg-indigo-700 hover:bg-indigo-800 px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                Salir
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Contenido principal */}
      <div className="container mx-auto px-4 py-6">
        {/* Botones de acción */}
        <div className="flex gap-3 mb-6 flex-wrap">
          <button
            onClick={() => setMostrarFormulario(!mostrarFormulario)}
            className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg flex items-center gap-2 font-medium transition-colors"
          >
            <Plus className="w-5 h-5" />
            Nuevo Pendiente
          </button>

          {usuarioActual.rol === 'compras' && (
            <>
              <button
                onClick={exportarExcel}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg flex items-center gap-2 font-medium transition-colors"
              >
                <Download className="w-5 h-5" />
                Exportar a Excel
              </button>

              <button
                onClick={() => setMostrarAgregarUsuario(!mostrarAgregarUsuario)}
                className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg flex items-center gap-2 font-medium transition-colors"
              >
                <UserPlus className="w-5 h-5" />
                Agregar Usuario
              </button>
            </>
          )}
        </div>

        {/* Formulario nuevo usuario (solo compras) */}
        {mostrarAgregarUsuario && usuarioActual.rol === 'compras' && (
          <div className="bg-white rounded-lg shadow-md p-6 mb-6 border-2 border-purple-200">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Agregar Nuevo Usuario</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Usuario (sin espacios)
                </label>
                <input
                  type="text"
                  value={nuevoUsuario.usuario}
                  onChange={(e) => setNuevoUsuario({ ...nuevoUsuario, usuario: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                  placeholder="Ej: JPEREZ"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nombre Completo
                </label>
                <input
                  type="text"
                  value={nuevoUsuario.nombre}
                  onChange={(e) => setNuevoUsuario({ ...nuevoUsuario, nombre: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                  placeholder="Nombre completo"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Contraseña
                </label>
                <input
                  type="text"
                  value={nuevoUsuario.password}
                  onChange={(e) => setNuevoUsuario({ ...nuevoUsuario, password: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                  placeholder="Contraseña inicial"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Rol
                </label>
                <select
                  value={nuevoUsuario.rol}
                  onChange={(e) => setNuevoUsuario({ ...nuevoUsuario, rol: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                >
                  <option value="facturacion">Auxiliar de Facturación</option>
                  <option value="compras">Equipo de Compras</option>
                </select>
              </div>

              <div className="md:col-span-2 flex gap-3">
                <button
                  onClick={agregarUsuario}
                  className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
                >
                  Agregar Usuario
                </button>
                <button
                  onClick={() => setMostrarAgregarUsuario(false)}
                  className="bg-gray-300 hover:bg-gray-400 text-gray-800 px-6 py-2 rounded-lg font-medium transition-colors"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Formulario nuevo pendiente */}
        {mostrarFormulario && (
          <div className="bg-white rounded-lg shadow-md p-6 mb-6 border-2 border-indigo-200">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Crear Nuevo Pendiente</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Fecha
                </label>
                <input
                  type="date"
                  value={nuevoPendiente.fecha}
                  onChange={(e) => setNuevoPendiente({ ...nuevoPendiente, fecha: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Empresa
                </label>
                <select
                  value={nuevoPendiente.empresa}
                  onChange={(e) => setNuevoPendiente({ ...nuevoPendiente, empresa: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="IMPSURMEDICALS">IMPSURMEDICALS</option>
                  <option value="HABILITEMOS">HABILITEMOS</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Producto *
                </label>
                <input
                  type="text"
                  value={nuevoPendiente.producto}
                  onChange={(e) => setNuevoPendiente({ ...nuevoPendiente, producto: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  placeholder="Nombre del producto"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Marca *
                </label>
                <input
                  type="text"
                  value={nuevoPendiente.marca}
                  onChange={(e) => setNuevoPendiente({ ...nuevoPendiente, marca: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  placeholder="Marca del producto"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Cantidad *
                </label>
                <input
                  type="text"
                  value={nuevoPendiente.cantidad}
                  onChange={(e) => setNuevoPendiente({ ...nuevoPendiente, cantidad: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  placeholder="Cantidad solicitada"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Cliente *
                </label>
                <input
                  type="text"
                  value={nuevoPendiente.cliente}
                  onChange={(e) => setNuevoPendiente({ ...nuevoPendiente, cliente: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  placeholder="Nombre del cliente"
                  required
                />
              </div>

              <div className="md:col-span-2 flex gap-3">
                <button
                  onClick={handleCrearPendiente}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
                >
                  Crear Pendiente
                </button>
                <button
                  onClick={() => setMostrarFormulario(false)}
                  className="bg-gray-300 hover:bg-gray-400 text-gray-800 px-6 py-2 rounded-lg font-medium transition-colors"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Panel de filtros */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
              <Search className="w-5 h-5" />
              Filtros de Búsqueda
            </h2>
            <button
              onClick={limpiarFiltros}
              className="text-sm text-indigo-600 hover:text-indigo-800 font-medium"
            >
              Limpiar filtros
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Buscar por Cliente
              </label>
              <input
                type="text"
                value={filtros.cliente}
                onChange={(e) => setFiltros({ ...filtros, cliente: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                placeholder="Nombre del cliente..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Empresa
              </label>
              <select
                value={filtros.empresa}
                onChange={(e) => setFiltros({ ...filtros, empresa: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              >
                <option value="TODAS">Todas las empresas</option>
                <option value="IMPSURMEDICALS">IMPSURMEDICALS</option>
                <option value="HABILITEMOS">HABILITEMOS</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Fecha Desde
              </label>
              <input
                type="date"
                value={filtros.fechaInicio}
                onChange={(e) => setFiltros({ ...filtros, fechaInicio: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Fecha Hasta
              </label>
              <input
                type="date"
                value={filtros.fechaFin}
                onChange={(e) => setFiltros({ ...filtros, fechaFin: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="mt-4 text-sm text-gray-600">
            Mostrando {pendientesFiltrados.length} de {pendientes.length} pendientes
          </div>
        </div>

        {/* Tabla de pendientes */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-indigo-600 text-white">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Fecha</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Empresa</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Producto</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Marca</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Cantidad</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Cliente</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Solicitado Por</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Días</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Estado</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">Observaciones</th>
                  {usuarioActual.rol === 'compras' && (
                    <th className="px-4 py-3 text-left text-sm font-semibold">Acciones</th>
                  )}
                </tr>
              </thead>
              <tbody>
                {pendientesFiltrados.length === 0 ? (
                  <tr>
                    <td colSpan={usuarioActual.rol === 'compras' ? 11 : 10} className="px-4 py-8 text-center text-gray-500">
                      {pendientes.length === 0 
                        ? 'No hay pendientes registrados. Crea uno nuevo para comenzar.'
                        : 'No se encontraron pendientes con los filtros aplicados.'}
                    </td>
                  </tr>
                ) : (
                  pendientesFiltrados.map((pendiente) => (
                    <tr key={pendiente.id} className={`border-b ${obtenerColor(pendiente)}`}>
                      <td className="px-4 py-3 text-sm">{pendiente.fecha}</td>
                      <td className="px-4 py-3 text-sm">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          pendiente.empresa === 'IMPSURMEDICALS' 
                            ? 'bg-blue-100 text-blue-800' 
                            : 'bg-purple-100 text-purple-800'
                        }`}>
                          {pendiente.empresa}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm font-medium">{pendiente.producto}</td>
                      <td className="px-4 py-3 text-sm">{pendiente.marca}</td>
                      <td className="px-4 py-3 text-sm">{pendiente.cantidad}</td>
                      <td className="px-4 py-3 text-sm">{pendiente.cliente}</td>
                      <td className="px-4 py-3 text-sm">{pendiente.solicitadoPor}</td>
                      <td className="px-4 py-3 text-sm font-bold">
                        {calcularDiasPendientes(pendiente.fecha)}
                      </td>
                      <td className="px-4 py-3 text-sm">
                        {pendiente.estado === 'ok' ? (
                          <span className="px-2 py-1 bg-green-600 text-white rounded text-xs font-bold">
                            OK
                          </span>
                        ) : (
                          <span className="px-2 py-1 bg-red-600 text-white rounded text-xs font-bold">
                            PENDIENTE
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-sm">
                        {usuarioActual.rol === 'compras' ? (
                          <input
                            type="text"
                            value={pendiente.observaciones}
                            onChange={(e) => actualizarObservaciones(pendiente.id, e.target.value)}
                            className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                            placeholder="Agregar observación..."
                          />
                        ) : (
                          <span className="text-gray-600">{pendiente.observaciones || '-'}</span>
                        )}
                      </td>
                      {usuarioActual.rol === 'compras' && (
                        <td className="px-4 py-3 text-sm">
                          <div className="flex gap-2">
                            {pendiente.estado !== 'ok' && (
                              <button
                                onClick={() => marcarComoOK(pendiente.id)}
                                className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-xs font-medium transition-colors"
                              >
                                Marcar OK
                              </button>
                            )}
                            <button
                              onClick={() => eliminarPendiente(pendiente.id)}
                              className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-xs font-medium transition-colors flex items-center gap-1"
                            >
                              <Trash2 className="w-3 h-3" />
                              Eliminar
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Estadísticas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6">
          <div className="bg-white rounded-lg shadow p-4 border-l-4 border-blue-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Total Pendientes</p>
                <p className="text-2xl font-bold text-gray-800">{pendientes.length}</p>
              </div>
              <Package className="w-10 h-10 text-blue-500 opacity-50" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-4 border-l-4 border-yellow-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Pendientes Activos</p>
                <p className="text-2xl font-bold text-gray-800">
                  {pendientes.filter(p => p.estado === 'pendiente').length}
                </p>
              </div>
              <Clock className="w-10 h-10 text-yellow-500 opacity-50" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-4 border-l-4 border-green-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Completados</p>
                <p className="text-2xl font-bold text-gray-800">
                  {pendientes.filter(p => p.estado === 'ok').length}
                </p>
              </div>
              <Users className="w-10 h-10 text-green-500 opacity-50" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-4 border-l-4 border-red-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Urgentes (+1 día)</p>
                <p className="text-2xl font-bold text-gray-800">
                  {pendientes.filter(p => p.estado === 'pendiente' && calcularDiasPendientes(p.fecha) > 1).length}
                </p>
              </div>
              <Calendar className="w-10 h-10 text-red-500 opacity-50" />
            </div>
          </div>
        </div>

        {/* Nota informativa */}
        <div className="mt-6 p-4 bg-green-50 rounded-lg border border-green-200">
          <p className="text-sm text-green-800">
            ✅ <strong>Información Sincronizada:</strong> Todos los cambios se guardan automáticamente en tiempo real y son visibles para todos los usuarios del sistema desde cualquier computador.
          </p>
        </div>
      </div>
    </div>
  );
};

export default PendientesCompraSystem;
